#include <atmel_start.h>

#include <driver_init.h>
#include <compiler.h>

typedef enum pwm_map_mode_t
{
	FEEDTHROUGH = 1,
	LINEAR_REMAP,
	NONLIN_REMAP,
	OPEN_LOOP,
	
} pwm_map_mode;

typedef struct global_state_t
{
	uint16_t ch0_freq;
	uint16_t ch0_duty;
	uint16_t ch1_freq;
	uint16_t ch1_duty;
	uint16_t ch2_freq;
	uint16_t ch2_duty;
	
	pwm_map_mode mode;
	
} global_state;


volatile uint8_t I2C_0_slave_address;
volatile uint8_t I2C_0_register_address;
volatile uint8_t I2C_0_num_addresses;
volatile uint8_t I2C_0_num_reads;
volatile uint8_t I2C_0_num_writes;
volatile uint8_t I2C_0_num_stops;

global_state sys_state;

ISR(TCB0_INT_vect)
{
	sys_state.ch0_freq = TCB0.CNT;
	sys_state.ch0_duty = TCB0.CCMP;  // Reading CCMP enables the timer for the next sample.

	/**
	 * The interrupt flag is cleared by writing 1 to it, or when the Capture register
	 * is read in Capture mode
	 */
	TCB0.INTFLAGS = TCB_CAPT_bm;
	
	
}

ISR(TCB1_INT_vect)
{
	sys_state.ch1_freq = TCB1.CNT;
	sys_state.ch1_duty = TCB1.CCMP;  // Reading CCMP enables the timer for the next sample.
	
	/**
	 * The interrupt flag is cleared by writing 1 to it, or when the Capture register
	 * is read in Capture mode
	 */
	TCB1.INTFLAGS = TCB_CAPT_bm;
	
}

ISR(TCB2_INT_vect)
{

	sys_state.ch2_freq = TCB2.CNT;
	sys_state.ch2_duty = TCB2.CCMP;  // Reading CCMP enables the timer for the next sample.
	
	/**
	 * The interrupt flag is cleared by writing 1 to it, or when the Capture register
	 * is read in Capture mode
	 */
	TCB2.INTFLAGS = TCB_CAPT_bm;
	
}



void I2C_0_address_handler()
{
	I2C_0_slave_address = I2C_0_read();
	I2C_0_send_ack(); // or send_nack() if we don't want to ack the address
	I2C_0_num_addresses++;
}

void I2C_0_read_handler()
{ 
	// Master read operation
	I2C_0_write(0x0c);
	I2C_0_num_reads++;
}

void I2C_0_write_handler()
{ 
	// Master write handler
	I2C_0_register_address = I2C_0_read();
	I2C_0_send_ack(); // or send_nack() if we don't want to receive more data
	I2C_0_num_writes++;
}

void I2C_0_stop_handler()
{
	I2C_0_num_stops++;
}

void I2C_0_error_handler()
{
	while (1)
	;
}


int main(void)
{
	// Initializes MCU, drivers and middleware 
	atmel_start_init();

	PWM_0_enable_output_ch0();
	PWM_0_enable_output_ch1();
	PWM_0_enable_output_ch2();

	I2C_0_set_read_callback(I2C_0_read_handler);
	I2C_0_set_write_callback(I2C_0_write_handler);
	I2C_0_set_address_callback(I2C_0_address_handler);
	I2C_0_set_stop_callback(I2C_0_stop_handler);
	I2C_0_set_collision_callback(I2C_0_error_handler);
	I2C_0_set_bus_error_callback(I2C_0_error_handler);
	I2C_0_open();


	/* Replace with your application code */
	while (1) 
	{
		
		PWM_0_load_duty_cycle_ch0(0x3f);
		PWM_0_load_duty_cycle_ch1(0x3f);
		PWM_0_load_duty_cycle_ch2(0x3f);
	
	}
}
