#include <atmel_start.h>

#include <util/delay.h>
#include <driver_init.h>
#include <compiler.h>

#include <stdio.h>

const uint8_t this_dev_addr = 0x11;

volatile uint8_t I2C_0_slave_address;
volatile uint8_t I2C_0_register_address;
volatile uint8_t I2C_0_num_addresses;
volatile uint8_t I2C_0_num_reads;
volatile uint8_t I2C_0_num_writes;
volatile uint8_t I2C_0_num_stops;

typedef enum pwm_map_mode_t
{
	FEEDTHROUGH = 1,
	LINEAR_REMAP,
	NONLIN_REMAP,
	OPEN_LOOP,
	
} pwm_map_mode;

typedef struct global_state_t
{
	uint16_t tach_1_freq;
	uint16_t tach_2_freq;
	uint16_t ctl_pwm_freq;
	uint16_t ctl_pwm_duty;
	
	pwm_map_mode mode;
	
} global_state;


global_state sys_state;

// Fan Tach 1
ISR(TCB0_INT_vect)
{
	sys_state.tach_1_freq = TCB0.CCMP;  // Reading CCMP enables the timer for the next sample.
	TCB0.INTFLAGS = TCB_CAPT_bm;  // Clear interrupt flag.
}

// Fan Tach 2
ISR(TCB1_INT_vect)
{
	sys_state.tach_2_freq = TCB1.CCMP;  // Reading CCMP enables the timer for the next sample.
	TCB1.INTFLAGS = TCB_CAPT_bm;  // Clear interrupt flag.
}


// Control PWM
ISR(TCB2_INT_vect)
{

	sys_state.ctl_pwm_freq = TCB2.CNT;
	sys_state.ctl_pwm_duty = TCB2.CCMP;  // Reading CCMP enables the timer for the next sample. 
	TCB2.INTFLAGS = TCB_CAPT_bm;  // Clear interrupt flag.
	
}



void I2C_0_address_handler()
{
	I2C_0_slave_address = I2C_0_read();
	I2C_0_send_ack(); // or send_nack() if we don't want to ack the address
	I2C_0_num_addresses++;
}

void I2C_0_read_handler()
{ 
	// Master read operation
	I2C_0_write(0x0c);
	I2C_0_num_reads++;
}

void I2C_0_write_handler()
{ 
	// Master write handler
	I2C_0_register_address = I2C_0_read();
	I2C_0_send_ack(); // or send_nack() if we don't want to receive more data
	I2C_0_num_writes++;
}

void I2C_0_stop_handler()
{
	I2C_0_num_stops++;
}

void I2C_0_error_handler()
{
	while (1)
	;
}


int main(void)
{
	// Initializes MCU, drivers and middleware 
	atmel_start_init();
	
	I2C_0_initialization(this_dev_addr);

	PWM_0_enable_output_ch0();
	PWM_0_enable_output_ch1();
	PWM_0_enable_output_ch2();

	I2C_0_set_read_callback(I2C_0_read_handler);
	I2C_0_set_write_callback(I2C_0_write_handler);
	I2C_0_set_address_callback(I2C_0_address_handler);
	I2C_0_set_stop_callback(I2C_0_stop_handler);
	I2C_0_set_collision_callback(I2C_0_error_handler);
	I2C_0_set_bus_error_callback(I2C_0_error_handler);
	I2C_0_open();


	PWM_0_load_top(0x315);
	PWM_0_load_duty_cycle_ch0(0x3f);
	PWM_0_load_duty_cycle_ch1(0x3f);
	PWM_0_load_duty_cycle_ch2(0x3f);
	
	// If USART Basic driver is in IRQ-mode, enable global interrupts.
	sei();
	
	/* Replace with your application code */
	while (1) 
	{
		_delay_ms(100);
		PORTD.OUTCLR = _BV(6);
		PORTD.OUTSET = _BV(7);
		_delay_ms(100);
		PORTD.OUTCLR = _BV(7);
		PORTD.OUTSET = _BV(6);
        
        printf("hello world");
	
	}
}
